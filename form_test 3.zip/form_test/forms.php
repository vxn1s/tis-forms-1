<?php
require_once "db.php";

// SMAZÁNÍ RECENZE
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_id"])) {
    $delete_id = intval($_POST["delete_id"]);

    $stmt = $pdo->prepare("DELETE FROM messages WHERE id = :id");
    $stmt->execute([":id" => $delete_id]);
}

// PŘIDÁNÍ RECENZE
if ($_SERVER["REQUEST_METHOD"] === "POST" && !isset($_POST["delete_id"])) {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $gamename = trim($_POST["gamename"] ?? "");
    $message = trim($_POST["message"] ?? "");
    $rating = isset($_POST["rating"]) ? intval($_POST["rating"]) : 0;

    $errors = [];

    if (empty($name)) $errors[] = "Jméno je povinné";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Neplatný email";
    if (empty($gamename)) $errors[] = "Název hry je povinný";
    if (empty($message)) $errors[] = "Zpráva je povinná";
    if ($rating < 1 || $rating > 5) $errors[] = "Hodnocení musí být 1–5";

    if (empty($errors)) {
        $sql = "INSERT INTO messages (name, email, gamename, message, rating)
                VALUES (:name, :email, :gamename, :message, :rating)";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ":name" => $name,
            ":email" => $email,
            ":gamename" => $gamename,
            ":message" => $message,
            ":rating" => $rating
        ]);
        header("Location: " . $_SERVER["PHP_SELF"]);
        exit;
    }
    
}

/* NAČTENÍ RECENZÍ */
$stmt = $pdo->query("SELECT * FROM messages ORDER BY created_at DESC");
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>