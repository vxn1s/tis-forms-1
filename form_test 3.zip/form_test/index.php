<?php
require_once "db.php";
require_once "forms.php";
?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <title>Recenze her</title>
     <link rel="stylesheet" href="style.css">
</head>
<body>


<?php if (!empty($errors)): ?>
    <div style="color:red;">
        <?php foreach ($errors as $error) echo "<p>$error</p>"; ?>
    </div>
<?php endif; ?>

<div class="container">
    <h2>Přidat recenzi</h2>
    <div class="form-section">
        <form method="POST">

            <div class="form-row">
                <input type="text" name="name" placeholder="Jméno">
                <input type="email" name="email" placeholder="Email">
            </div>

            <div class="form-row">
                <input type="text" name="gamename" placeholder="Název hry">
            </div>

            <div class="form-row rating-row">
                <label><input type="radio" name="rating" value="1">1</label>
                <label><input type="radio" name="rating" value="2">2</label>
                <label><input type="radio" name="rating" value="3">3</label>
                <label><input type="radio" name="rating" value="4">4</label>
                <label><input type="radio" name="rating" value="5">5</label>
            </div>

            <div class="form-row">
                <textarea name="message" placeholder="Text recenze"></textarea>
            </div>

            <div class="form-buttons">
                <button type="submit">Odeslat recenzi</button>
                <button type="reset">Vymazat</button>
            </div>

        </form>
    </div>

<hr>

<h2>Recenze</h2>

<?php foreach ($messages as $row): ?>
    <div class="review">

        <h3><?= htmlspecialchars($row["gamename"]) ?></h3>

        <p><strong><?= htmlspecialchars($row["name"]) ?></strong></p>

        <p><?= htmlspecialchars($row["message"]) ?></p>

        <p>
            <?php
            for ($i = 1; $i <= 5; $i++) {
                echo $i <= $row["rating"] ? "&#9733;" : "&#9734;";
            }
            ?>
        </p>

        
        <form method="POST" style="display:inline;">
            <input type="hidden" name="delete_id" value="<?= $row["id"] ?>">
            <button type="submit" class="btn">Smazat recenzi</button>
        </form>

    </div>
<?php endforeach; ?>

</body>
</html>